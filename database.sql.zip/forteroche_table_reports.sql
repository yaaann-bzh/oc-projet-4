
-- --------------------------------------------------------

--
-- Structure de la table `reports`
--

DROP TABLE IF EXISTS `reports`;
CREATE TABLE IF NOT EXISTS `reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `authorId` int(11) NOT NULL,
  `commentId` int(11) NOT NULL,
  `content` varchar(255) NOT NULL,
  `commentContent` text NOT NULL,
  `reportDate` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `comment` (`commentId`),
  KEY `member` (`authorId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
