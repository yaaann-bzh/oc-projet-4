
-- --------------------------------------------------------

--
-- Structure de la table `fort_exple_comments`
--

DROP TABLE IF EXISTS `fort_exple_comments`;
CREATE TABLE IF NOT EXISTS `fort_exple_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `removed` tinyint(1) NOT NULL DEFAULT '0',
  `postId` int(11) NOT NULL,
  `memberId` int(11) NOT NULL,
  `content` text COLLATE utf8_bin NOT NULL,
  `addDate` datetime NOT NULL,
  `updateDate` datetime DEFAULT NULL,
  `reportDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `post` (`postId`),
  KEY `commentAuthor` (`memberId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
