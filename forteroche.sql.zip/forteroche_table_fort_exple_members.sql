
-- --------------------------------------------------------

--
-- Structure de la table `fort_exple_members`
--

DROP TABLE IF EXISTS `fort_exple_members`;
CREATE TABLE IF NOT EXISTS `fort_exple_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `privilege` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `pseudo` varchar(255) COLLATE utf8_bin NOT NULL,
  `email` varchar(255) COLLATE utf8_bin NOT NULL,
  `pass` varchar(255) COLLATE utf8_bin NOT NULL,
  `lastname` varchar(255) COLLATE utf8_bin NOT NULL,
  `firstname` varchar(255) COLLATE utf8_bin NOT NULL,
  `inscriptionDate` datetime NOT NULL,
  `deleteDate` datetime DEFAULT NULL,
  `connexionId` varchar(25) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `pseudo` (`pseudo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
