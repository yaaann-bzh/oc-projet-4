
--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `fort_exple_comments`
--
ALTER TABLE `fort_exple_comments`
  ADD CONSTRAINT `exple_commentAuthor` FOREIGN KEY (`memberId`) REFERENCES `fort_exple_members` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `exple_post` FOREIGN KEY (`postId`) REFERENCES `fort_exple_posts` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Contraintes pour la table `fort_exple_posts`
--
ALTER TABLE `fort_exple_posts`
  ADD CONSTRAINT `exple_author` FOREIGN KEY (`authorId`) REFERENCES `fort_exple_members` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Contraintes pour la table `fort_exple_reports`
--
ALTER TABLE `fort_exple_reports`
  ADD CONSTRAINT `exple_comment` FOREIGN KEY (`commentId`) REFERENCES `fort_exple_comments` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `exple_member` FOREIGN KEY (`authorId`) REFERENCES `fort_exple_members` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;
