
-- --------------------------------------------------------

--
-- Structure de la table `fort_exple_reports`
--

DROP TABLE IF EXISTS `fort_exple_reports`;
CREATE TABLE IF NOT EXISTS `fort_exple_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `authorId` int(11) NOT NULL,
  `commentId` int(11) NOT NULL,
  `content` varchar(255) NOT NULL,
  `commentContent` text NOT NULL,
  `reportDate` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `comment` (`commentId`),
  KEY `member` (`authorId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
